%% Rollout policy
% r  = starting inventory
% D  = demand
% P  = selling price
% C  = production costs
% Q  = production capacity

function [fval, x] = DeterministicIPSellingwProd(r, D, P, C, Q)

n_x     = length(D);    % Time periods forward
e       = ones(n_x,1);

%% Objective function
f = [P; -C; zeros(n_x,1)];

%% Constraint Matrix
X = spdiags(e, 0, n_x, n_x);
Y = -X;
R = spdiags([-1*e e], 0:1, n_x, n_x);
Aeq = [X Y R];
A = [X Y -X];

%% Bounds

x_lb = zeros(n_x,1);
x_ub = D;

y_lb = zeros(n_x,1);
y_ub = Q;

lb = [x_lb; y_lb; zeros(n_x,1)];
ub = [x_ub; y_ub; 1e5*e];
ub(2*n_x+1) = r;

%% INTLINPROG IMPLEMENTATION
        options = optimoptions('intlinprog');
        options.Display = 'off';
%         [x, fval, exitflag] = intlinprog(f, 1:n_x, [], [], Aeq, beq, lb, ub, options);

%% GUROBI IMPLEMENTATION - works as same as intlinprog in MATLAB, aside from options
% [x, fval, exitflag] = intlinprog_GUROBI(-f, 1:n_x, A,zeros(n_x,1), Aeq, zeros(n_x,1), lb, ub);
[x, fval, exitflag] = intlinprog(-f, 1:n_x, A,zeros(n_x,1), Aeq, zeros(n_x,1), lb, ub, options);
%         fprintf('fval: %d, D*P: %d\n', fval, D'*P);
fval = -fval;
x = x(n_x+1:2*n_x);

end