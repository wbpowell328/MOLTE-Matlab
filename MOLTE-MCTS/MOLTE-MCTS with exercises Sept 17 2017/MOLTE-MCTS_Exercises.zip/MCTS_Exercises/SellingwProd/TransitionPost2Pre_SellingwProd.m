
function currNode = TransitionPost2Pre_SellingwProd(prevNode, currNode, w)
    currNode.inv = prevNode.inv;
    if currNode.acc_profit == 0
        currNode.acc_profit = prevNode.acc_profit + w*prevNode.action;
    end
end