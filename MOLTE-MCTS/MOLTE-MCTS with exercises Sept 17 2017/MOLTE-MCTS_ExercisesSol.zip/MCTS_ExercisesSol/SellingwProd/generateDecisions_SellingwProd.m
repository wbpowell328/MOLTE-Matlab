function decisions = generateDecisions_SellingwProd(q)
decisions = 0:1:q;
end

% %% OLD
% function decisions = generateDecisions_SellingwProd(d, inv, t)
% leftover = 6*t - inv;
% if leftover <= 0
%     decisions = 6;
% elseif leftover > 6
%     decisions = d;
% else
%     decisions = leftover:6:6;
% end
% end