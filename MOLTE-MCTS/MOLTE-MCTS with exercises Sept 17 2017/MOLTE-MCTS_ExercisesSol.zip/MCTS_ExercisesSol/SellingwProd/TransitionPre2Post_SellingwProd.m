function currNode = TransitionPre2Post_SellingwProd(prevNode, currNode, x)
    currNode.inv = prevNode.inv + x;
    currNode.acc_profit = prevNode.acc_profit;
end

%% OLD
% function currNode = TransitionPre2Post_SellingwProd(prevNode, currNode, x)
%     currNode.inv = prevNode.inv - x;
%     currNode.acc_profit = prevNode.acc_profit;
% end