function Node = SimPolicy_SellingwProd(Node, t_final, forecast, rolloutPolicy)

if Node.V_x ~= 0
    return;
end

D = forecast.demand;
D = D(Node.t:t_final);
P = forecast.price(Node.t:t_final);
C = forecast.cost(Node.t:t_final);
Q = forecast.capacity(Node.t:t_final);
r = Node.inv;

if Node.N == 0 && Node.t <= t_final
    
    fval = rolloutPolicy(r, D, P, C, Q);

    % Assign Value to Node
    Node.V_x = Node.acc_profit + fval;
    
end
end