function currNode = TransitionPost2Pre_SellingwProd(prevNode, currNode, w, demand, cost)
currNode.inv = max(0, prevNode.inv - demand);
currNode.acc_profit = prevNode.acc_profit - cost*prevNode.action + w*min(prevNode.inv, demand);
end

%% OLD
% function currNode = TransitionPost2Pre_SellingwProd(prevNode, currNode, w)
%     currNode.inv = prevNode.inv;
%     if currNode.acc_profit == 0
%         currNode.acc_profit = prevNode.acc_profit + w*prevNode.action;
%     end
% end